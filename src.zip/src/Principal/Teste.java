package Principal;
import Usuarios.*;
import Itens.*;
import java.util.Date;
public class Teste {
	
	public static void main(String[] args) {
		Sistema tc = new Sistema();
		tc.menu();
		
	}
}
