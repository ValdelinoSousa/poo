package Itens;
import Usuarios.Usuarios;
public class Periodico extends Livro {
	public Periodico(String tit) {
		super(tit);
	}
	@Override
	public boolean empresta(Usuarios u, int prazo) {
		if (u.getProfessor()) {
			return super.empresta(u, 7);
		} else {
			return false;
		}
	}
}