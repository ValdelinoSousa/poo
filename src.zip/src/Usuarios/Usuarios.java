package Usuarios;
import java.util.ArrayList;
import Itens.*;


public class Usuarios {
	
	private String nome;
	protected int nivelDePrivilegio;
	protected ArrayList<Item> itensRetirados;
	
	
	public Usuarios(String nome) {
		this.nome = nome;
		this.nivelDePrivilegio = 1;
		this.itensRetirados = new ArrayList<Item>();
	}
	

	public String getNome() {
		return nome;
	}

	public boolean retiraItem(Item it) {

		if (it.getDisponivel()) {
			it.empresta(this, getPrazoMaximo());
			this.itensRetirados.add(it);
			return true;
		}
		return false;
	}
	
	
	public boolean devolveItem(Item it) {
		this.itensRetirados.remove(it);
		it.retorna(this);
		return true;
	}

	public int getCotaMaxima() {
		return 2;
	}

	public int getPrazoMaximo() {
		return 4;
	}

	public boolean getADevolver() {
		return ((this.itensRetirados.size() >= this.getCotaMaxima() || this.temPrazoVencido()) ? true : false);
	}

	public boolean getAptoARetirar() {
		return (!this.getADevolver());
	}

	public boolean temPrazoVencido() {
		for (Item item : this.itensRetirados) {
			if (item.isEmAtraso()) {
				return true;
			}

		}
		return false;
	}

	public boolean getProfessor() {
		return false;
	}

	public String toString() {
		return "Usuario " + nome;
	}

	public String listaCarga() {
		StringBuilder carga = new StringBuilder();
		carga.append(this.toString()).append(" Limite: ").append(this.getCotaMaxima()).append(" Carga atual: ")
				.append(this.itensRetirados.size());
		for (Item item : this.itensRetirados) {
			carga.append(item.toString()).append("\n");
		}
		return carga.toString();
	}
	
	public int getNivelPriv() {
		return this.nivelDePrivilegio;
	}
	public ArrayList<Item> getItens(){
		return this.itensRetirados;
	}
}